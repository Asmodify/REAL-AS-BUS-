export type Language = 'zh' | 'mn';

export interface Translation {
  [key: string]: string | Translation;
}

const translations: Record<Language, Translation> = {
  zh: {
    // Navigation
    dashboard: '仪表板',
    cargo: '货物管理',
    vehicles: '车辆追踪',
    companies: '公司管理',
    drivers: '司机管理',
    reports: '报告',
    settings: '设置',
    
    // Common
    search: '搜索...',
    online: '在线',
    offline: '离线',
    idle: '空闲',
    loading: '加载中...',
    error: '错误',
    success: '成功',
    cancel: '取消',
    save: '保存',
    edit: '编辑',
    delete: '删除',
    view: '查看',
    add: '添加',
    create: '创建',
    update: '更新',
    refresh: '刷新',
    
    // Dashboard
    cargoManagementSystem: '货物管理系统',
    realTimeMonitoring: '实时监控和管理您的货运操作',
    activeShipments: '活跃货运',
    totalVehicles: '总车辆数',
    partnerCompanies: '合作公司',
    thisMonth: '本月收入',
    quickActions: '快捷操作',
    newShipment: '新建货运',
    liveTracking: '实时追踪',
    generateReport: '生成报告',
    addCompany: '添加公司',
    systemSettings: '系统设置',
    
    // Shipments
    recentShipments: '最近货运',
    shipmentId: '货运ID',
    originCompany: '发货公司',
    destination: '目的地',
    driver: '司机',
    status: '状态',
    eta: '预计到达',
    actions: '操作',
    pending: '待处理',
    inTransit: '运输中',
    delivered: '已送达',
    cancelled: '已取消',
    
    // Vehicle tracking
    liveVehicleTracking: '实时位置追踪',
    mapView: '地图视图将在此处显示',
    activeVehicles: '活跃车辆',
    viewAllVehicles: '查看所有车辆',
    
    // Forms
    createNewShipment: '创建新货运',
    selectCompany: '选择公司',
    selectDriver: '选择司机',
    expectedDelivery: '预计送达时间',
    cargoDescription: '货物描述',
    enterDestination: '输入目的地地址',
    describeCargoDetails: '描述货物类型、重量、特殊要求等...',
    createShipmentBtn: '创建货运',
    
    // Status messages
    welcomeMessage: '欢迎使用货物管理系统！',
    newShipmentCreated: '新货运创建成功！',
    dataRefreshed: '货运数据已刷新',
    unauthorized: '未授权',
    loggedOut: '您已登出。正在重新登录...',
  },
  mn: {
    // Navigation
    dashboard: 'Хяналтын самбар',
    cargo: 'Ачаа удирдлага',
    vehicles: 'Тээврийн хэрэгсэл хянах',
    companies: 'Компани удирдлага',
    drivers: 'Жолооч удирдлага',
    reports: 'Тайлан',
    settings: 'Тохиргоо',
    
    // Common
    search: 'Хайх...',
    online: 'Онлайн',
    offline: 'Оффлайн',
    idle: 'Зогссон',
    loading: 'Ачааллаж байна...',
    error: 'Алдаа',
    success: 'Амжилттай',
    cancel: 'Цуцлах',
    save: 'Хадгалах',
    edit: 'Засах',
    delete: 'Устгах',
    view: 'Харах',
    add: 'Нэмэх',
    create: 'Үүсгэх',
    update: 'Шинэчлэх',
    refresh: 'Сэргээх',
    
    // Dashboard
    cargoManagementSystem: 'Ачаа удирдлагын систем',
    realTimeMonitoring: 'Таны ачаа тээврийн үйл ажиллагааг бодит цагт хянах, удирдах',
    activeShipments: 'Идэвхтэй тээвэр',
    totalVehicles: 'Нийт тээврийн хэрэгсэл',
    partnerCompanies: 'Хамтрагч компаниуд',
    thisMonth: 'Энэ сарын орлого',
    quickActions: 'Хурдан үйлдэл',
    newShipment: 'Шинэ тээвэр',
    liveTracking: 'Шууд мөрдөх',
    generateReport: 'Тайлан гаргах',
    addCompany: 'Компани нэмэх',
    systemSettings: 'Системийн тохиргоо',
    
    // Shipments
    recentShipments: 'Сүүлийн тээвэр',
    shipmentId: 'Тээврийн ID',
    originCompany: 'Илгээгч компани',
    destination: 'Очих газар',
    driver: 'Жолооч',
    status: 'Төлөв',
    eta: 'Хүрэх цаг',
    actions: 'Үйлдэл',
    pending: 'Хүлээгдэж буй',
    inTransit: 'Тээвэрлэж буй',
    delivered: 'Хүргэгдсэн',
    cancelled: 'Цуцалсан',
    
    // Vehicle tracking
    liveVehicleTracking: 'Тээврийн хэрэгслийн шууд байршил',
    mapView: 'Газрын зурагийн харагдац энд харагдана',
    activeVehicles: 'Идэвхтэй тээврийн хэрэгсэл',
    viewAllVehicles: 'Бүх тээврийн хэрэгсэл харах',
    
    // Forms
    createNewShipment: 'Шинэ тээвэр үүсгэх',
    selectCompany: 'Компани сонгох',
    selectDriver: 'Жолооч сонгох',
    expectedDelivery: 'Хүргэх төлөвлөгөөт цаг',
    cargoDescription: 'Ачааны тайлбар',
    enterDestination: 'Очих газрын хаягийг оруулах',
    describeCargoDetails: 'Ачааны төрөл, жин, тусгай шаардлага гэх мэт...',
    createShipmentBtn: 'Тээвэр үүсгэх',
    
    // Status messages
    welcomeMessage: 'Ачаа удирдлагын системд тавтай морил!',
    newShipmentCreated: 'Шинэ тээвэр амжилттай үүсгэгдлээ!',
    dataRefreshed: 'Тээврийн өгөгдөл шинэчлэгдлээ',
    unauthorized: 'Зөвшөөрөлгүй',
    loggedOut: 'Та гарсан байна. Дахин нэвтэрч байна...',
  },
};

export function useTranslation(language: Language = 'zh') {
  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        // Fallback to Chinese if key not found in selected language
        value = translations.zh;
        for (const fallbackKey of keys) {
          if (value && typeof value === 'object' && fallbackKey in value) {
            value = value[fallbackKey];
          } else {
            return key; // Return key if not found in any language
          }
        }
        break;
      }
    }
    
    return typeof value === 'string' ? value : key;
  };
  
  return { t };
}
