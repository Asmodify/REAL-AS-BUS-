import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { ShipmentsTable } from "@/components/ShipmentsTable";
import { NewShipmentModal } from "@/components/NewShipmentModal";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { Plus } from "lucide-react";

export default function Cargo() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { language } = useLanguage();
  const [newShipmentModalOpen, setNewShipmentModalOpen] = useState(false);
  const { t } = useTranslation(language);

  return (
    <ProtectedRoute>
      <div className="flex h-screen overflow-hidden">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header onMenuClick={() => setSidebarOpen(true)} />
          
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <div className="px-4 py-6 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{t('cargo')}</h1>
                  <p className="text-gray-600">Manage all shipments and cargo operations</p>
                </div>
                
                <Button 
                  onClick={() => setNewShipmentModalOpen(true)}
                  className="bg-primary text-black hover:bg-yellow-400"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  {t('newShipment')}
                </Button>
              </div>

              <ShipmentsTable language={language} />
            </div>
          </main>
        </div>

        <NewShipmentModal
          open={newShipmentModalOpen}
          onOpenChange={setNewShipmentModalOpen}
          language={language}
        />
      </div>
    </ProtectedRoute>
  );
}
