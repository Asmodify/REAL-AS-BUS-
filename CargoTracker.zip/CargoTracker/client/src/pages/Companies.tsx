import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Building, Plus, Edit, Trash2 } from "lucide-react";

export default function Companies() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<any>(null);
  const { language } = useLanguage();
  const { t } = useTranslation(language);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: '',
    nameEn: '',
    nameMn: '',
    address: '',
    contactPerson: '',
    phone: '',
    email: '',
  });

  const { data: companies, isLoading } = useQuery({
    queryKey: ['/api/companies'],
  });

  const createCompanyMutation = useMutation({
    mutationFn: async (companyData: any) => {
      const response = await apiRequest('POST', '/api/companies', companyData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/companies'] });
      toast({
        title: t('success'),
        description: 'Company created successfully',
      });
      setModalOpen(false);
      resetForm();
    },
    onError: handleError,
  });

  const updateCompanyMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/companies/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/companies'] });
      toast({
        title: t('success'),
        description: 'Company updated successfully',
      });
      setModalOpen(false);
      setEditingCompany(null);
      resetForm();
    },
    onError: handleError,
  });

  const deleteCompanyMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/companies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/companies'] });
      toast({
        title: t('success'),
        description: 'Company deleted successfully',
      });
    },
    onError: handleError,
  });

  function handleError(error: any) {
    if (isUnauthorizedError(error)) {
      toast({
        title: t('unauthorized'),
        description: t('loggedOut'),
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
    toast({
      title: t('error'),
      description: error.message,
      variant: "destructive",
    });
  }

  const resetForm = () => {
    setFormData({
      name: '',
      nameEn: '',
      nameMn: '',
      address: '',
      contactPerson: '',
      phone: '',
      email: '',
    });
  };

  const handleEdit = (company: any) => {
    setEditingCompany(company);
    setFormData({
      name: company.name || '',
      nameEn: company.nameEn || '',
      nameMn: company.nameMn || '',
      address: company.address || '',
      contactPerson: company.contactPerson || '',
      phone: company.phone || '',
      email: company.email || '',
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingCompany) {
      updateCompanyMutation.mutate({ id: editingCompany.id, data: formData });
    } else {
      createCompanyMutation.mutate(formData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this company?')) {
      deleteCompanyMutation.mutate(id);
    }
  };

  return (
    <ProtectedRoute requiredRole={['AD_OPERATOR', 'AD_EREEN']}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header onMenuClick={() => setSidebarOpen(true)} />
          
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <div className="px-4 py-6 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{t('companies')}</h1>
                  <p className="text-gray-600">Manage partner companies and contacts</p>
                </div>
                
                <Dialog open={modalOpen} onOpenChange={setModalOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      className="bg-primary text-black hover:bg-yellow-400"
                      onClick={() => {
                        setEditingCompany(null);
                        resetForm();
                      }}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      {t('addCompany')}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>
                        {editingCompany ? 'Edit Company' : t('addCompany')}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Company Name (Chinese)</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                            className="border-black focus:ring-primary"
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="nameEn">Company Name (English)</Label>
                          <Input
                            id="nameEn"
                            value={formData.nameEn}
                            onChange={(e) => setFormData(prev => ({ ...prev, nameEn: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="nameMn">Company Name (Mongolian)</Label>
                          <Input
                            id="nameMn"
                            value={formData.nameMn}
                            onChange={(e) => setFormData(prev => ({ ...prev, nameMn: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="contactPerson">Contact Person</Label>
                          <Input
                            id="contactPerson"
                            value={formData.contactPerson}
                            onChange={(e) => setFormData(prev => ({ ...prev, contactPerson: e.target.value }))}
                            className="border-black focus:ring-primary"
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            value={formData.phone}
                            onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                            className="border-black focus:ring-primary"
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="address">Address</Label>
                        <Input
                          id="address"
                          value={formData.address}
                          onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                          className="border-black focus:ring-primary"
                          required
                        />
                      </div>
                      
                      <div className="flex justify-end space-x-3">
                        <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                          {t('cancel')}
                        </Button>
                        <Button 
                          type="submit" 
                          className="bg-primary text-black hover:bg-yellow-400"
                          disabled={createCompanyMutation.isPending || updateCompanyMutation.isPending}
                        >
                          {editingCompany ? t('update') : t('create')}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Companies Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {isLoading ? (
                  [...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="h-4 bg-gray-200 rounded mb-4"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded"></div>
                      </CardContent>
                    </Card>
                  ))
                ) : companies?.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No companies found</h3>
                    <p className="text-gray-600">Get started by adding your first company.</p>
                  </div>
                ) : (
                  companies?.map((company: any) => (
                    <Card key={company.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mr-3">
                              <Building className="h-5 w-5 text-black" />
                            </div>
                            <div>
                              <CardTitle className="text-lg">{company.name}</CardTitle>
                              {company.isActive && (
                                <Badge variant="secondary" className="bg-green-100 text-green-800 mt-1">
                                  Active
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex space-x-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(company)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(company.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="space-y-2 text-sm text-gray-600">
                          <div><strong>Contact:</strong> {company.contactPerson}</div>
                          <div><strong>Phone:</strong> {company.phone}</div>
                          {company.email && <div><strong>Email:</strong> {company.email}</div>}
                          <div><strong>Address:</strong> {company.address}</div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
}
