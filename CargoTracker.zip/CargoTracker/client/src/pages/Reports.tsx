import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { BarChart3, Download, Calendar, TrendingUp, Package, Truck, Building } from "lucide-react";

export default function Reports() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { language } = useLanguage();
  const [reportType, setReportType] = useState("monthly");
  const { t } = useTranslation(language);

  const { data: stats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
  });

  const { data: shipmentsData } = useQuery({
    queryKey: ['/api/shipments'],
  });

  const { data: vehicles } = useQuery({
    queryKey: ['/api/vehicles'],
  });

  const { data: companies } = useQuery({
    queryKey: ['/api/companies'],
  });

  // Calculate report data
  const shipments = shipmentsData?.shipments || [];
  
  const getReportData = () => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    
    const thisMonthShipments = shipments.filter((s: any) => {
      const shipmentDate = new Date(s.createdAt);
      return shipmentDate.getMonth() === currentMonth && shipmentDate.getFullYear() === currentYear;
    });

    const lastMonthShipments = shipments.filter((s: any) => {
      const shipmentDate = new Date(s.createdAt);
      const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
      const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;
      return shipmentDate.getMonth() === lastMonth && shipmentDate.getFullYear() === lastMonthYear;
    });

    const deliveredThisMonth = thisMonthShipments.filter((s: any) => s.status === 'delivered').length;
    const deliveredLastMonth = lastMonthShipments.filter((s: any) => s.status === 'delivered').length;
    
    const deliveryRate = thisMonthShipments.length > 0 ? (deliveredThisMonth / thisMonthShipments.length) * 100 : 0;
    const lastMonthDeliveryRate = lastMonthShipments.length > 0 ? (deliveredLastMonth / lastMonthShipments.length) * 100 : 0;
    
    return {
      thisMonth: {
        total: thisMonthShipments.length,
        delivered: deliveredThisMonth,
        pending: thisMonthShipments.filter((s: any) => s.status === 'pending').length,
        inTransit: thisMonthShipments.filter((s: any) => s.status === 'in_transit' || s.status === 'in-transit').length,
        deliveryRate,
      },
      lastMonth: {
        total: lastMonthShipments.length,
        delivered: deliveredLastMonth,
        deliveryRate: lastMonthDeliveryRate,
      },
      growth: {
        shipments: lastMonthShipments.length > 0 ? ((thisMonthShipments.length - lastMonthShipments.length) / lastMonthShipments.length) * 100 : 0,
        deliveryRate: deliveryRate - lastMonthDeliveryRate,
      }
    };
  };

  const reportData = getReportData();

  const generateReport = () => {
    // In a real implementation, this would generate and download a PDF or Excel file
    alert('Report generation feature would be implemented here');
  };

  const reportTypes = [
    { value: "daily", label: "Daily Report" },
    { value: "weekly", label: "Weekly Report" },
    { value: "monthly", label: "Monthly Report" },
    { value: "quarterly", label: "Quarterly Report" },
    { value: "yearly", label: "Annual Report" },
  ];

  return (
    <ProtectedRoute requiredRole={['AD_OPERATOR', 'AD_EREEN']}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header onMenuClick={() => setSidebarOpen(true)} />
          
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <div className="px-4 py-6 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{t('reports')}</h1>
                  <p className="text-gray-600">Analytics and performance reports</p>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger className="w-48 border-black">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {reportTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Button 
                    onClick={generateReport}
                    className="bg-primary text-black hover:bg-yellow-400"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    {t('generateReport')}
                  </Button>
                </div>
              </div>

              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                          <Package className="h-5 w-5 text-black" />
                        </div>
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            This Month Shipments
                          </dt>
                          <dd className="flex items-baseline">
                            <span className="text-2xl font-bold text-gray-900">
                              {reportData.thisMonth.total}
                            </span>
                            {reportData.growth.shipments !== 0 && (
                              <span className={`ml-2 flex items-baseline text-sm font-semibold ${
                                reportData.growth.shipments > 0 ? 'text-green-600' : 'text-red-600'
                              }`}>
                                <TrendingUp className="self-center flex-shrink-0 h-4 w-4" />
                                {Math.abs(reportData.growth.shipments).toFixed(1)}%
                              </span>
                            )}
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <div className="w-8 h-8 bg-green-100 rounded-md flex items-center justify-center">
                          <TrendingUp className="h-5 w-5 text-green-600" />
                        </div>
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Delivery Rate
                          </dt>
                          <dd className="flex items-baseline">
                            <span className="text-2xl font-bold text-gray-900">
                              {reportData.thisMonth.deliveryRate.toFixed(1)}%
                            </span>
                            {reportData.growth.deliveryRate !== 0 && (
                              <span className={`ml-2 flex items-baseline text-sm font-semibold ${
                                reportData.growth.deliveryRate > 0 ? 'text-green-600' : 'text-red-600'
                              }`}>
                                {reportData.growth.deliveryRate > 0 ? '+' : ''}
                                {reportData.growth.deliveryRate.toFixed(1)}%
                              </span>
                            )}
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <div className="w-8 h-8 bg-blue-100 rounded-md flex items-center justify-center">
                          <Truck className="h-5 w-5 text-blue-600" />
                        </div>
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Active Vehicles
                          </dt>
                          <dd className="text-2xl font-bold text-gray-900">
                            {vehicles?.filter((v: any) => v.status !== 'offline').length || 0}
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <div className="w-8 h-8 bg-purple-100 rounded-md flex items-center justify-center">
                          <Building className="h-5 w-5 text-purple-600" />
                        </div>
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Partner Companies
                          </dt>
                          <dd className="text-2xl font-bold text-gray-900">
                            {companies?.length || 0}
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Detailed Reports */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Shipment Status Breakdown */}
                <Card>
                  <CardHeader>
                    <CardTitle>Shipment Status Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Delivered</span>
                        <div className="flex items-center">
                          <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                            <div 
                              className="bg-green-500 h-2 rounded-full" 
                              style={{ width: `${reportData.thisMonth.total > 0 ? (reportData.thisMonth.delivered / reportData.thisMonth.total) * 100 : 0}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium">{reportData.thisMonth.delivered}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">In Transit</span>
                        <div className="flex items-center">
                          <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                            <div 
                              className="bg-blue-500 h-2 rounded-full" 
                              style={{ width: `${reportData.thisMonth.total > 0 ? (reportData.thisMonth.inTransit / reportData.thisMonth.total) * 100 : 0}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium">{reportData.thisMonth.inTransit}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Pending</span>
                        <div className="flex items-center">
                          <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                            <div 
                              className="bg-yellow-500 h-2 rounded-full" 
                              style={{ width: `${reportData.thisMonth.total > 0 ? (reportData.thisMonth.pending / reportData.thisMonth.total) * 100 : 0}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium">{reportData.thisMonth.pending}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Vehicle Utilization */}
                <Card>
                  <CardHeader>
                    <CardTitle>Vehicle Utilization</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {vehicles?.slice(0, 5).map((vehicle: any) => {
                        const vehicleShipments = shipments.filter((s: any) => s.vehicleId === vehicle.id);
                        const utilizationRate = vehicleShipments.length;
                        
                        return (
                          <div key={vehicle.id} className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">{vehicle.licensePlate}</span>
                            <div className="flex items-center">
                              <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                                <div 
                                  className="bg-primary h-2 rounded-full" 
                                  style={{ width: `${Math.min(utilizationRate * 10, 100)}%` }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium">{utilizationRate}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                {/* Monthly Comparison */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Monthly Performance Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-8">
                      <div>
                        <h4 className="font-medium text-gray-900 mb-3">This Month</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Total Shipments:</span>
                            <span className="font-medium">{reportData.thisMonth.total}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Delivered:</span>
                            <span className="font-medium">{reportData.thisMonth.delivered}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Delivery Rate:</span>
                            <span className="font-medium">{reportData.thisMonth.deliveryRate.toFixed(1)}%</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-medium text-gray-900 mb-3">Last Month</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Total Shipments:</span>
                            <span className="font-medium">{reportData.lastMonth.total}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Delivered:</span>
                            <span className="font-medium">{reportData.lastMonth.delivered}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Delivery Rate:</span>
                            <span className="font-medium">{reportData.lastMonth.deliveryRate.toFixed(1)}%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
}
