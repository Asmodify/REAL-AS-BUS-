import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Settings as SettingsIcon, User, Bell, Shield, Database, Globe } from "lucide-react";

export default function Settings() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { language } = useLanguage();
  const { t } = useTranslation(language);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const [profileSettings, setProfileSettings] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    language: user?.language || 'zh',
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    shipmentUpdates: true,
    systemAlerts: true,
    weeklyReports: false,
  });

  const [systemSettings, setSystemSettings] = useState({
    autoRefresh: true,
    refreshInterval: '30',
    theme: 'light',
    timezone: 'UTC+8',
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      // In a real implementation, this would update user profile
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: t('success'),
        description: 'Profile updated successfully',
      });
    },
    onError: handleError,
  });

  const updateNotificationsMutation = useMutation({
    mutationFn: async (data: any) => {
      // In a real implementation, this would update notification preferences
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: t('success'),
        description: 'Notification settings updated',
      });
    },
    onError: handleError,
  });

  const updateSystemMutation = useMutation({
    mutationFn: async (data: any) => {
      // In a real implementation, this would update system preferences
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: t('success'),
        description: 'System settings updated',
      });
    },
    onError: handleError,
  });

  function handleError(error: any) {
    if (isUnauthorizedError(error)) {
      toast({
        title: t('unauthorized'),
        description: t('loggedOut'),
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
    toast({
      title: t('error'),
      description: error.message,
      variant: "destructive",
    });
  }

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(profileSettings);
  };

  const handleNotificationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateNotificationsMutation.mutate(notificationSettings);
  };

  const handleSystemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSystemMutation.mutate(systemSettings);
  };

  const handleLogout = () => {
    if (confirm('Are you sure you want to logout?')) {
      window.location.href = "/api/logout";
    }
  };

  return (
    <ProtectedRoute requiredRole={['AD_OPERATOR']}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header onMenuClick={() => setSidebarOpen(true)} />
          
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <div className="px-4 py-6 sm:px-6 lg:px-8">
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900">{t('settings')}</h1>
                <p className="text-gray-600">Manage your account and system preferences</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Profile Settings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <User className="mr-2 h-5 w-5" />
                      Profile Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleProfileSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="firstName">First Name</Label>
                          <Input
                            id="firstName"
                            value={profileSettings.firstName}
                            onChange={(e) => setProfileSettings(prev => ({ ...prev, firstName: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="lastName">Last Name</Label>
                          <Input
                            id="lastName"
                            value={profileSettings.lastName}
                            onChange={(e) => setProfileSettings(prev => ({ ...prev, lastName: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={profileSettings.email}
                          onChange={(e) => setProfileSettings(prev => ({ ...prev, email: e.target.value }))}
                          className="border-black focus:ring-primary"
                          disabled
                        />
                        <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                      </div>
                      
                      <div>
                        <Label htmlFor="profileLanguage">Preferred Language</Label>
                        <Select 
                          value={profileSettings.language} 
                          onValueChange={(value) => setProfileSettings(prev => ({ ...prev, language: value }))}
                        >
                          <SelectTrigger className="border-black focus:ring-primary">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="zh">中文 (Chinese)</SelectItem>
                            <SelectItem value="mn">Монгол (Mongolian)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="bg-primary text-black hover:bg-yellow-400"
                        disabled={updateProfileMutation.isPending}
                      >
                        {updateProfileMutation.isPending ? t('loading') : t('save')}
                      </Button>
                    </form>
                  </CardContent>
                </Card>

                {/* Notification Settings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Bell className="mr-2 h-5 w-5" />
                      Notification Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleNotificationSubmit} className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="emailNotifications">Email Notifications</Label>
                          <p className="text-sm text-gray-500">Receive notifications via email</p>
                        </div>
                        <Switch
                          id="emailNotifications"
                          checked={notificationSettings.emailNotifications}
                          onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, emailNotifications: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="shipmentUpdates">Shipment Updates</Label>
                          <p className="text-sm text-gray-500">Get notified about shipment status changes</p>
                        </div>
                        <Switch
                          id="shipmentUpdates"
                          checked={notificationSettings.shipmentUpdates}
                          onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, shipmentUpdates: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="systemAlerts">System Alerts</Label>
                          <p className="text-sm text-gray-500">Important system notifications</p>
                        </div>
                        <Switch
                          id="systemAlerts"
                          checked={notificationSettings.systemAlerts}
                          onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, systemAlerts: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="weeklyReports">Weekly Reports</Label>
                          <p className="text-sm text-gray-500">Receive weekly performance reports</p>
                        </div>
                        <Switch
                          id="weeklyReports"
                          checked={notificationSettings.weeklyReports}
                          onCheckedChange={(checked) => setNotificationSettings(prev => ({ ...prev, weeklyReports: checked }))}
                        />
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="bg-primary text-black hover:bg-yellow-400"
                        disabled={updateNotificationsMutation.isPending}
                      >
                        {updateNotificationsMutation.isPending ? t('loading') : t('save')}
                      </Button>
                    </form>
                  </CardContent>
                </Card>

                {/* System Settings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <SettingsIcon className="mr-2 h-5 w-5" />
                      System Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSystemSubmit} className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="autoRefresh">Auto Refresh</Label>
                          <p className="text-sm text-gray-500">Automatically refresh data</p>
                        </div>
                        <Switch
                          id="autoRefresh"
                          checked={systemSettings.autoRefresh}
                          onCheckedChange={(checked) => setSystemSettings(prev => ({ ...prev, autoRefresh: checked }))}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="refreshInterval">Refresh Interval (seconds)</Label>
                        <Select 
                          value={systemSettings.refreshInterval} 
                          onValueChange={(value) => setSystemSettings(prev => ({ ...prev, refreshInterval: value }))}
                        >
                          <SelectTrigger className="border-black focus:ring-primary">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="15">15 seconds</SelectItem>
                            <SelectItem value="30">30 seconds</SelectItem>
                            <SelectItem value="60">1 minute</SelectItem>
                            <SelectItem value="300">5 minutes</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="timezone">Timezone</Label>
                        <Select 
                          value={systemSettings.timezone} 
                          onValueChange={(value) => setSystemSettings(prev => ({ ...prev, timezone: value }))}
                        >
                          <SelectTrigger className="border-black focus:ring-primary">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="UTC+8">UTC+8 (Beijing)</SelectItem>
                            <SelectItem value="UTC+8">UTC+8 (Ulaanbaatar)</SelectItem>
                            <SelectItem value="UTC">UTC</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="bg-primary text-black hover:bg-yellow-400"
                        disabled={updateSystemMutation.isPending}
                      >
                        {updateSystemMutation.isPending ? t('loading') : t('save')}
                      </Button>
                    </form>
                  </CardContent>
                </Card>

                {/* Security */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Shield className="mr-2 h-5 w-5" />
                      Security
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <Label>Account Status</Label>
                        <p className="text-sm text-gray-600">Your account is active</p>
                      </div>
                      
                      <div>
                        <Label>Role</Label>
                        <p className="text-sm text-gray-600">{user?.role}</p>
                      </div>
                      
                      <div>
                        <Label>Last Login</Label>
                        <p className="text-sm text-gray-600">Current session</p>
                      </div>
                      
                      <Separator />
                      
                      <Button 
                        variant="destructive"
                        onClick={handleLogout}
                        className="w-full"
                      >
                        Logout
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* System Information */}
              <Card className="mt-8">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Database className="mr-2 h-5 w-5" />
                    System Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <Label>Application Version</Label>
                      <p className="text-sm text-gray-600">v1.0.0</p>
                    </div>
                    
                    <div>
                      <Label>Last Update</Label>
                      <p className="text-sm text-gray-600">{new Date().toLocaleDateString()}</p>
                    </div>
                    
                    <div>
                      <Label>System Status</Label>
                      <p className="text-sm text-green-600">All systems operational</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
}
