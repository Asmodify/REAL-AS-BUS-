import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Truck, BarChart3, Building, Users, Package, MapPin } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mr-3">
                <Truck className="h-6 w-6 text-black" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">CargoFlow</h1>
                <p className="text-sm text-gray-500">Management System</p>
              </div>
            </div>
            <Button 
              onClick={handleLogin}
              className="bg-primary text-black hover:bg-yellow-400"
            >
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            货物管理系统
            <br />
            <span className="text-2xl text-gray-600">Cargo Management System</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            实时监控和管理您的货运操作，支持多角色用户管理和实时车辆追踪
            <br />
            <span className="text-lg">Real-time monitoring and management of your cargo operations with multi-role user management and live vehicle tracking</span>
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-primary text-black hover:bg-yellow-400 text-lg px-8 py-3"
          >
            Get Started - 开始使用
          </Button>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <Package className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                货物管理 / Cargo Management
              </h3>
              <p className="text-gray-600">
                Complete cargo tracking and management system with real-time status updates
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <MapPin className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                实时追踪 / Live Tracking
              </h3>
              <p className="text-gray-600">
                Real-time vehicle tracking with GPS integration and route optimization
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <Users className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                多角色管理 / Multi-Role Management
              </h3>
              <p className="text-gray-600">
                Support for operators, drivers, and administrators with role-based access
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <Building className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                公司管理 / Company Management
              </h3>
              <p className="text-gray-600">
                Comprehensive company and partner management system
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <BarChart3 className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                报告分析 / Analytics & Reports
              </h3>
              <p className="text-gray-600">
                Detailed analytics and reporting for better business insights
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <Truck className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                车队管理 / Fleet Management
              </h3>
              <p className="text-gray-600">
                Complete fleet management with maintenance tracking and driver assignment
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Supported Languages */}
        <div className="text-center bg-white rounded-lg shadow p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            多语言支持 / Multilingual Support
          </h2>
          <p className="text-gray-600 mb-6">
            支持中文和蒙古语，为不同地区的用户提供便利
            <br />
            Supports Chinese and Mongolian languages for users in different regions
          </p>
          <div className="flex justify-center space-x-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">中文</div>
              <div className="text-sm text-gray-600">Chinese</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">Монгол</div>
              <div className="text-sm text-gray-600">Mongolian</div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 CargoFlow Management System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
