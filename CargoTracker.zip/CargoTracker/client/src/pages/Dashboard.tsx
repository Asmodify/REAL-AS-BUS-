import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { DashboardStats } from "@/components/DashboardStats";
import { ShipmentsTable } from "@/components/ShipmentsTable";
import { VehicleTracking } from "@/components/VehicleTracking";
import { NewShipmentModal } from "@/components/NewShipmentModal";
import { LanguageSelector } from "@/components/LanguageSelector";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { Plus, MapPin, BarChart3, Building, Settings, Target } from "lucide-react";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [newShipmentModalOpen, setNewShipmentModalOpen] = useState(false);
  const { language, setLanguage } = useLanguage();
  const { t } = useTranslation(language);

  const quickActions = [
    {
      title: t('newShipment'),
      titleEn: 'New Shipment',
      icon: Plus,
      color: 'text-primary',
      onClick: () => setNewShipmentModalOpen(true),
    },
    {
      title: t('liveTracking'),
      titleEn: 'Live Tracking',
      icon: MapPin,
      color: 'text-blue-600',
      onClick: () => console.log('Live tracking'),
    },
    {
      title: t('generateReport'),
      titleEn: 'Generate Report',
      icon: BarChart3,
      color: 'text-green-600',
      onClick: () => console.log('Generate report'),
    },
    {
      title: t('addCompany'),
      titleEn: 'Add Company',
      icon: Building,
      color: 'text-purple-600',
      onClick: () => console.log('Add company'),
    },
    {
      title: t('systemSettings'),
      titleEn: 'Settings',
      icon: Settings,
      color: 'text-gray-600',
      onClick: () => console.log('Settings'),
    },
  ];

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
          <div className="px-4 py-6 sm:px-6 lg:px-8">
            {/* Dashboard Stats */}
            <DashboardStats />

            {/* Quick Actions */}
            <div className="mb-8">
              <h2 className="text-lg font-medium text-gray-900 mb-4">
                {t('quickActions')}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {quickActions.map((action, index) => {
                  const Icon = action.icon;
                  return (
                    <Card
                      key={index}
                      className="cursor-pointer hover:shadow-md transition-shadow border-2 border-transparent hover:border-primary"
                      onClick={action.onClick}
                    >
                      <CardContent className="p-4 text-center">
                        <Icon className={`h-8 w-8 ${action.color} mx-auto mb-2`} />
                        <p className="text-sm font-medium text-gray-900 mb-1">
                          {action.title}
                        </p>
                        <p className="text-xs text-gray-500">
                          {action.titleEn}
                        </p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Recent Shipments Table */}
            <ShipmentsTable />

            {/* Live Vehicle Tracking */}
            <VehicleTracking />
          </div>
        </main>
      </div>

      {/* New Shipment Modal */}
      <NewShipmentModal
        open={newShipmentModalOpen}
        onOpenChange={setNewShipmentModalOpen}
      />
    </div>
  );
}
