import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Truck, Plus, Edit, Trash2, MapPin, Navigation } from "lucide-react";

export default function Vehicles() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { language } = useLanguage();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<any>(null);
  const { t } = useTranslation(language);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    licensePlate: '',
    driverId: '',
    model: '',
    capacity: '',
    status: 'offline',
    currentLocation: '',
  });

  const { data: vehicles, isLoading } = useQuery({
    queryKey: ['/api/vehicles'],
  });

  const createVehicleMutation = useMutation({
    mutationFn: async (vehicleData: any) => {
      const response = await apiRequest('POST', '/api/vehicles', vehicleData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      toast({
        title: t('success'),
        description: 'Vehicle created successfully',
      });
      setModalOpen(false);
      resetForm();
    },
    onError: handleError,
  });

  const updateVehicleMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/vehicles/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      toast({
        title: t('success'),
        description: 'Vehicle updated successfully',
      });
      setModalOpen(false);
      setEditingVehicle(null);
      resetForm();
    },
    onError: handleError,
  });

  const deleteVehicleMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/vehicles/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      toast({
        title: t('success'),
        description: 'Vehicle deleted successfully',
      });
    },
    onError: handleError,
  });

  function handleError(error: any) {
    if (isUnauthorizedError(error)) {
      toast({
        title: t('unauthorized'),
        description: t('loggedOut'),
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
    toast({
      title: t('error'),
      description: error.message,
      variant: "destructive",
    });
  }

  const resetForm = () => {
    setFormData({
      licensePlate: '',
      driverId: '',
      model: '',
      capacity: '',
      status: 'offline',
      currentLocation: '',
    });
  };

  const handleEdit = (vehicle: any) => {
    setEditingVehicle(vehicle);
    setFormData({
      licensePlate: vehicle.licensePlate || '',
      driverId: vehicle.driverId || '',
      model: vehicle.model || '',
      capacity: vehicle.capacity || '',
      status: vehicle.status || 'offline',
      currentLocation: vehicle.currentLocation || '',
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const vehicleData = {
      ...formData,
      capacity: formData.capacity ? parseFloat(formData.capacity) : null,
    };

    if (editingVehicle) {
      updateVehicleMutation.mutate({ id: editingVehicle.id, data: vehicleData });
    } else {
      createVehicleMutation.mutate(vehicleData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this vehicle?')) {
      deleteVehicleMutation.mutate(id);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'online':
        return <Badge className="bg-green-100 text-green-800">{t('online')}</Badge>;
      case 'offline':
        return <Badge variant="secondary" className="bg-red-100 text-red-800">{t('offline')}</Badge>;
      case 'idle':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">{t('idle')}</Badge>;
      case 'in_transit':
        return <Badge variant="secondary" className="bg-blue-100 text-blue-800">{t('inTransit')}</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <ProtectedRoute requiredRole={['AD_OPERATOR', 'AD_EREEN']}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header onMenuClick={() => setSidebarOpen(true)} />
          
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <div className="px-4 py-6 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{t('vehicles')}</h1>
                  <p className="text-gray-600">Manage fleet vehicles and tracking</p>
                </div>
                
                <Dialog open={modalOpen} onOpenChange={setModalOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      className="bg-primary text-black hover:bg-yellow-400"
                      onClick={() => {
                        setEditingVehicle(null);
                        resetForm();
                      }}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add Vehicle
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>
                        {editingVehicle ? 'Edit Vehicle' : 'Add Vehicle'}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="licensePlate">License Plate</Label>
                          <Input
                            id="licensePlate"
                            value={formData.licensePlate}
                            onChange={(e) => setFormData(prev => ({ ...prev, licensePlate: e.target.value }))}
                            className="border-black focus:ring-primary"
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="model">Vehicle Model</Label>
                          <Input
                            id="model"
                            value={formData.model}
                            onChange={(e) => setFormData(prev => ({ ...prev, model: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="capacity">Capacity (tons)</Label>
                          <Input
                            id="capacity"
                            type="number"
                            step="0.1"
                            value={formData.capacity}
                            onChange={(e) => setFormData(prev => ({ ...prev, capacity: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="status">Status</Label>
                          <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                            <SelectTrigger className="border-black focus:ring-primary">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="offline">{t('offline')}</SelectItem>
                              <SelectItem value="online">{t('online')}</SelectItem>
                              <SelectItem value="idle">{t('idle')}</SelectItem>
                              <SelectItem value="in_transit">{t('inTransit')}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label htmlFor="driverId">Driver ID</Label>
                          <Input
                            id="driverId"
                            value={formData.driverId}
                            onChange={(e) => setFormData(prev => ({ ...prev, driverId: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="currentLocation">Current Location</Label>
                          <Input
                            id="currentLocation"
                            value={formData.currentLocation}
                            onChange={(e) => setFormData(prev => ({ ...prev, currentLocation: e.target.value }))}
                            className="border-black focus:ring-primary"
                          />
                        </div>
                      </div>
                      
                      <div className="flex justify-end space-x-3">
                        <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                          {t('cancel')}
                        </Button>
                        <Button 
                          type="submit" 
                          className="bg-primary text-black hover:bg-yellow-400"
                          disabled={createVehicleMutation.isPending || updateVehicleMutation.isPending}
                        >
                          {editingVehicle ? t('update') : t('create')}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Vehicles Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {isLoading ? (
                  [...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="h-4 bg-gray-200 rounded mb-4"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded"></div>
                      </CardContent>
                    </Card>
                  ))
                ) : vehicles?.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <Truck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No vehicles found</h3>
                    <p className="text-gray-600">Get started by adding your first vehicle.</p>
                  </div>
                ) : (
                  vehicles?.map((vehicle: any) => (
                    <Card key={vehicle.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center">
                            <div className={`w-10 h-10 ${vehicle.status === 'offline' ? 'bg-gray-200' : 'bg-primary'} rounded-lg flex items-center justify-center mr-3`}>
                              <Truck className={`h-5 w-5 ${vehicle.status === 'offline' ? 'text-gray-600' : 'text-black'}`} />
                            </div>
                            <div>
                              <CardTitle className="text-lg">{vehicle.licensePlate}</CardTitle>
                              {getStatusBadge(vehicle.status)}
                            </div>
                          </div>
                          <div className="flex space-x-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(vehicle)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(vehicle.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="space-y-2 text-sm text-gray-600">
                          {vehicle.model && <div><strong>Model:</strong> {vehicle.model}</div>}
                          {vehicle.capacity && <div><strong>Capacity:</strong> {vehicle.capacity} tons</div>}
                          {vehicle.driverId && <div><strong>Driver:</strong> {vehicle.driverId}</div>}
                          {vehicle.currentLocation && (
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 mr-1" />
                              <span>{vehicle.currentLocation}</span>
                            </div>
                          )}
                          {vehicle.lastUpdate && (
                            <div className="text-xs text-gray-500">
                              Last update: {new Date(vehicle.lastUpdate).toLocaleString()}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
}
