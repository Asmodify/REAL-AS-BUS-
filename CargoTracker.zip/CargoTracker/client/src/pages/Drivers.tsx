import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { Users, User, Truck, Package } from "lucide-react";

export default function Drivers() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { language } = useLanguage();
  const { t } = useTranslation(language);

  const { data: vehicles, isLoading: vehiclesLoading } = useQuery({
    queryKey: ['/api/vehicles'],
  });

  const { data: shipments, isLoading: shipmentsLoading } = useQuery({
    queryKey: ['/api/shipments'],
  });

  // Get unique drivers from vehicles and shipments
  const drivers = vehicles?.filter((v: any) => v.driverId).map((v: any) => ({
    id: v.driverId,
    name: v.driverId,
    vehicle: v,
    status: v.status,
  })) || [];

  const getDriverShipments = (driverId: string) => {
    return shipments?.shipments?.filter((s: any) => s.driverId === driverId) || [];
  };

  const getDriverStats = (driverId: string) => {
    const driverShipments = getDriverShipments(driverId);
    return {
      total: driverShipments.length,
      completed: driverShipments.filter((s: any) => s.status === 'delivered').length,
      inProgress: driverShipments.filter((s: any) => s.status === 'in_transit' || s.status === 'in-transit').length,
    };
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'online':
        return <Badge className="bg-green-100 text-green-800">{t('online')}</Badge>;
      case 'offline':
        return <Badge variant="secondary" className="bg-red-100 text-red-800">{t('offline')}</Badge>;
      case 'idle':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">{t('idle')}</Badge>;
      case 'in_transit':
        return <Badge variant="secondary" className="bg-blue-100 text-blue-800">{t('inTransit')}</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <ProtectedRoute requiredRole={['AD_OPERATOR']}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header onMenuClick={() => setSidebarOpen(true)} />
          
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <div className="px-4 py-6 sm:px-6 lg:px-8">
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900">{t('drivers')}</h1>
                <p className="text-gray-600">Manage drivers and monitor their performance</p>
              </div>

              {/* Drivers Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {vehiclesLoading || shipmentsLoading ? (
                  [...Array(6)].map((_, i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="h-4 bg-gray-200 rounded mb-4"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded"></div>
                      </CardContent>
                    </Card>
                  ))
                ) : drivers.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No drivers found</h3>
                    <p className="text-gray-600">Drivers will appear here when vehicles are assigned to them.</p>
                  </div>
                ) : (
                  drivers.map((driver: any) => {
                    const stats = getDriverStats(driver.id);
                    return (
                      <Card key={driver.id} className="hover:shadow-lg transition-shadow">
                        <CardHeader className="pb-3">
                          <div className="flex items-center">
                            <Avatar className="h-12 w-12 mr-4">
                              <AvatarFallback>
                                <User className="h-6 w-6" />
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <CardTitle className="text-lg">{driver.name}</CardTitle>
                              {getStatusBadge(driver.status)}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="space-y-3">
                            {/* Vehicle Information */}
                            <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                              <Truck className="h-5 w-5 text-gray-600 mr-3" />
                              <div>
                                <p className="text-sm font-medium text-gray-900">
                                  {driver.vehicle.licensePlate}
                                </p>
                                <p className="text-xs text-gray-500">
                                  {driver.vehicle.model || 'Vehicle'} 
                                  {driver.vehicle.capacity && ` • ${driver.vehicle.capacity}t`}
                                </p>
                              </div>
                            </div>

                            {/* Performance Stats */}
                            <div className="grid grid-cols-3 gap-2 text-center">
                              <div className="p-2 bg-blue-50 rounded">
                                <div className="text-lg font-bold text-blue-600">{stats.total}</div>
                                <div className="text-xs text-blue-600">Total</div>
                              </div>
                              <div className="p-2 bg-green-50 rounded">
                                <div className="text-lg font-bold text-green-600">{stats.completed}</div>
                                <div className="text-xs text-green-600">Completed</div>
                              </div>
                              <div className="p-2 bg-yellow-50 rounded">
                                <div className="text-lg font-bold text-yellow-600">{stats.inProgress}</div>
                                <div className="text-xs text-yellow-600">Active</div>
                              </div>
                            </div>

                            {/* Current Location */}
                            {driver.vehicle.currentLocation && (
                              <div className="text-sm text-gray-600">
                                <strong>Location:</strong> {driver.vehicle.currentLocation}
                              </div>
                            )}

                            {/* Last Update */}
                            {driver.vehicle.lastUpdate && (
                              <div className="text-xs text-gray-500">
                                Last update: {new Date(driver.vehicle.lastUpdate).toLocaleString()}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                )}
              </div>

              {/* Recent Driver Activity */}
              {drivers.length > 0 && (
                <Card className="mt-8">
                  <CardHeader>
                    <CardTitle>Recent Driver Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {drivers.slice(0, 5).map((driver: any) => {
                        const recentShipments = getDriverShipments(driver.id).slice(0, 2);
                        return (
                          <div key={driver.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-3">
                                <AvatarFallback>
                                  <User className="h-4 w-4" />
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium text-gray-900">{driver.name}</p>
                                <p className="text-xs text-gray-500">{driver.vehicle.licensePlate}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              {getStatusBadge(driver.status)}
                              {recentShipments.length > 0 && (
                                <p className="text-xs text-gray-500 mt-1">
                                  Last: {recentShipments[0].destination}
                                </p>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
}
