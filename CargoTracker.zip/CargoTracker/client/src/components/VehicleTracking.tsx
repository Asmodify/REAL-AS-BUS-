import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { Truck, Map, Navigation } from "lucide-react";

export function VehicleTracking() {
  const { language } = useLanguage();
  const { t } = useTranslation(language);
  
  const { data: vehicles, isLoading } = useQuery({
    queryKey: ['/api/vehicles'],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
      case 'in_transit':
        return 'bg-green-500';
      case 'idle':
        return 'bg-yellow-500';
      case 'offline':
      default:
        return 'bg-red-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'online':
        return t('online');
      case 'offline':
        return t('offline');
      case 'idle':
        return t('idle');
      case 'in_transit':
        return t('inTransit');
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Loading...</CardTitle>
          </CardHeader>
          <CardContent>
            <Skeleton className="w-full h-64" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Loading...</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const activeVehicles = vehicles?.filter((v: any) => v.status !== 'offline') || [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Map View */}
      <Card>
        <CardHeader>
          <CardTitle>{t('liveVehicleTracking')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
            <div className="text-center">
              <Map className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">{t('mapView')}</p>
              <p className="text-sm text-gray-400">Map view will be displayed here</p>
            </div>
          </div>
          
          {/* Vehicle Status Legend */}
          <div className="mt-4 flex items-center space-x-6">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600">{t('online')}</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600">{t('idle')}</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600">{t('offline')}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Vehicles List */}
      <Card>
        <CardHeader>
          <CardTitle>{t('activeVehicles')}</CardTitle>
        </CardHeader>
        <CardContent>
          {activeVehicles.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No active vehicles found
            </div>
          ) : (
            <div className="space-y-4">
              {activeVehicles.slice(0, 5).map((vehicle: any) => (
                <div key={vehicle.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 ${vehicle.status === 'offline' ? 'bg-gray-200' : 'bg-primary'} rounded-lg flex items-center justify-center mr-3`}>
                      <Truck className={`h-5 w-5 ${vehicle.status === 'offline' ? 'text-gray-600' : 'text-black'}`} />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{vehicle.licensePlate}</p>
                      <p className="text-xs text-gray-500">{vehicle.driverId || 'No driver assigned'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 ${getStatusColor(vehicle.status)} rounded-full mr-2`}></div>
                      <span className="text-xs text-gray-600">{getStatusText(vehicle.status)}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {vehicle.currentLocation || 'Location unknown'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          <Button 
            className="w-full mt-4 bg-yellow-50 text-primary border border-primary hover:bg-yellow-100"
            variant="outline"
          >
            {t('viewAllVehicles')}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
