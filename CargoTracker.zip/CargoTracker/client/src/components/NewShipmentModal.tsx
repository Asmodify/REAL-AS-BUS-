import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

interface NewShipmentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function NewShipmentModal({ open, onOpenChange }: NewShipmentModalProps) {
  const { language } = useLanguage();
  const { t } = useTranslation(language);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    originCompanyId: '',
    destination: '',
    destinationAddress: '',
    driverId: '',
    vehicleId: '',
    cargoDescription: '',
    cargoWeight: '',
    estimatedDelivery: '',
  });

  const { data: companies } = useQuery({
    queryKey: ['/api/companies'],
    enabled: open,
  });

  const { data: vehicles } = useQuery({
    queryKey: ['/api/vehicles'],
    enabled: open,
  });

  const createShipmentMutation = useMutation({
    mutationFn: async (shipmentData: any) => {
      const response = await apiRequest('POST', '/api/shipments', shipmentData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shipments'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      toast({
        title: t('success'),
        description: t('newShipmentCreated'),
      });
      onOpenChange(false);
      setFormData({
        originCompanyId: '',
        destination: '',
        destinationAddress: '',
        driverId: '',
        vehicleId: '',
        cargoDescription: '',
        cargoWeight: '',
        estimatedDelivery: '',
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: t('unauthorized'),
          description: t('loggedOut'),
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t('error'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const shipmentData = {
      ...formData,
      originCompanyId: formData.originCompanyId ? parseInt(formData.originCompanyId) : null,
      vehicleId: formData.vehicleId ? parseInt(formData.vehicleId) : null,
      cargoWeight: formData.cargoWeight ? parseFloat(formData.cargoWeight) : null,
      estimatedDelivery: formData.estimatedDelivery ? new Date(formData.estimatedDelivery) : null,
    };

    createShipmentMutation.mutate(shipmentData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('createNewShipment')}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="originCompany">{t('originCompany')}</Label>
              <Select value={formData.originCompanyId} onValueChange={(value) => handleInputChange('originCompanyId', value)}>
                <SelectTrigger className="border-black focus:ring-primary">
                  <SelectValue placeholder={t('selectCompany')} />
                </SelectTrigger>
                <SelectContent>
                  {companies?.map((company: any) => (
                    <SelectItem key={company.id} value={company.id.toString()}>
                      {company.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="destination">{t('destination')}</Label>
              <Input
                id="destination"
                value={formData.destination}
                onChange={(e) => handleInputChange('destination', e.target.value)}
                placeholder={t('enterDestination')}
                className="border-black focus:ring-primary"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="destinationAddress">Destination Address</Label>
              <Input
                id="destinationAddress"
                value={formData.destinationAddress}
                onChange={(e) => handleInputChange('destinationAddress', e.target.value)}
                placeholder="Enter detailed address"
                className="border-black focus:ring-primary"
              />
            </div>
            
            <div>
              <Label htmlFor="vehicle">Assign Vehicle</Label>
              <Select value={formData.vehicleId} onValueChange={(value) => handleInputChange('vehicleId', value)}>
                <SelectTrigger className="border-black focus:ring-primary">
                  <SelectValue placeholder="Select Vehicle" />
                </SelectTrigger>
                <SelectContent>
                  {vehicles?.map((vehicle: any) => (
                    <SelectItem key={vehicle.id} value={vehicle.id.toString()}>
                      {vehicle.licensePlate} - {vehicle.driverId || 'No driver'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="cargoWeight">Cargo Weight (kg)</Label>
              <Input
                id="cargoWeight"
                type="number"
                step="0.01"
                value={formData.cargoWeight}
                onChange={(e) => handleInputChange('cargoWeight', e.target.value)}
                placeholder="Enter weight"
                className="border-black focus:ring-primary"
              />
            </div>
            
            <div>
              <Label htmlFor="estimatedDelivery">{t('expectedDelivery')}</Label>
              <Input
                id="estimatedDelivery"
                type="datetime-local"
                value={formData.estimatedDelivery}
                onChange={(e) => handleInputChange('estimatedDelivery', e.target.value)}
                className="border-black focus:ring-primary"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="cargoDescription">{t('cargoDescription')}</Label>
            <Textarea
              id="cargoDescription"
              rows={3}
              value={formData.cargoDescription}
              onChange={(e) => handleInputChange('cargoDescription', e.target.value)}
              placeholder={t('describeCargoDetails')}
              className="border-black focus:ring-primary"
            />
          </div>
          
          <div className="flex items-center justify-end space-x-3 pt-4">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={createShipmentMutation.isPending}
            >
              {t('cancel')}
            </Button>
            <Button 
              type="submit"
              className="bg-primary text-black hover:bg-yellow-400"
              disabled={createShipmentMutation.isPending}
            >
              {createShipmentMutation.isPending ? t('loading') : t('createShipmentBtn')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
