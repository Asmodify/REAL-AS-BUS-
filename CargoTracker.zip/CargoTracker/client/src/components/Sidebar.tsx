import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { LanguageSelector } from "./LanguageSelector";
import { useTranslation } from "@/lib/i18n";
import { useLanguage } from "@/hooks/useLanguage";
import { Truck, BarChart3, Building, Users, FileText, Settings, Package, LayoutDashboard, Wifi, WifiOff, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();
  const { language, setLanguage } = useLanguage();
  const { t } = useTranslation(language);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Monitor connection status
  useState(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  });

  const navigation = [
    { name: t('dashboard'), href: '/', icon: LayoutDashboard, current: location === '/' },
    { name: t('cargo'), href: '/cargo', icon: Package, current: location === '/cargo' },
    { name: t('vehicles'), href: '/vehicles', icon: Truck, current: location === '/vehicles' },
    { name: t('companies'), href: '/companies', icon: Building, current: location === '/companies' },
    { name: t('drivers'), href: '/drivers', icon: Users, current: location === '/drivers' },
    { name: t('reports'), href: '/reports', icon: FileText, current: location === '/reports' },
    { name: t('settings'), href: '/settings', icon: Settings, current: location === '/settings' },
  ];

  // Filter navigation based on user role
  const filteredNavigation = navigation.filter(item => {
    if (!user) return false;
    
    switch (user.role) {
      case 'AD_OPERATOR':
        return true; // Full access
      case 'AD_EREEN':
        return !['drivers', 'settings'].includes(item.href.slice(1)); // Limited access
      case 'AD_DRIVER':
        return ['/', '/cargo', '/vehicles'].includes(item.href); // Driver only access
      default:
        return false;
    }
  });

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 lg:hidden bg-gray-600 bg-opacity-50"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out
        lg:translate-x-0 lg:static lg:inset-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
          {/* Logo Section */}
          <div className="flex items-center flex-shrink-0 px-4 pt-5 mb-8">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Truck className="h-6 w-6 text-black" />
              </div>
              <div className="ml-3">
                <h1 className="text-xl font-bold text-gray-900">CargoFlow</h1>
                <p className="text-sm text-gray-500">Management System</p>
              </div>
            </div>
          </div>

          {/* User Profile */}
          {user && (
            <div className="flex items-center px-4 py-3 bg-gray-50 mx-4 rounded-lg mb-6">
              <Avatar className="h-10 w-10">
                <AvatarImage src={user.profileImageUrl || undefined} />
                <AvatarFallback>
                  <User className="h-6 w-6" />
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">
                  {user.firstName || user.lastName 
                    ? `${user.firstName || ''} ${user.lastName || ''}`.trim()
                    : user.email || 'User'
                  }
                </p>
                <p className="text-xs text-gray-500">{user.role}</p>
              </div>
            </div>
          )}

          {/* Language Selector */}
          <div className="px-4 mb-6">
            <LanguageSelector value={language} onChange={setLanguage} />
          </div>

          {/* Navigation Menu */}
          <nav className="flex-1 px-2 space-y-1">
            {filteredNavigation.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.name} href={item.href}>
                  <div
                    className={`
                      group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors cursor-pointer
                      ${item.current
                        ? 'bg-primary text-black'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }
                    `}
                    onClick={onClose}
                  >
                    <Icon className={`mr-3 h-5 w-5 ${item.current ? 'text-black' : 'text-gray-400 group-hover:text-gray-500'}`} />
                    {item.name}
                  </div>
                </Link>
              );
            })}
          </nav>

          {/* Connection Status */}
          <div className="flex-shrink-0 px-4 py-4 border-t border-gray-200">
            <div className="flex items-center">
              {isOnline ? (
                <Wifi className="w-4 h-4 text-green-500 mr-2" />
              ) : (
                <WifiOff className="w-4 h-4 text-red-500 mr-2" />
              )}
              <span className="text-sm text-gray-600">
                {isOnline ? t('online') : t('offline')}
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
