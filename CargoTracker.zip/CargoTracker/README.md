# Cargo Management System

A comprehensive multi-role cargo management web application with user authentication, company management, and cargo tracking capabilities.

## Features

- **Multi-role Authentication**: Support for AD_OPERATOR, AD_EREEN, and AD_DRIVER roles
- **Company Management**: Full CRUD operations for shipping companies
- **Vehicle Tracking**: Real-time vehicle location and status monitoring
- **Cargo Management**: Complete shipment lifecycle tracking
- **Multilingual Support**: Chinese and Mongolian language support
- **Responsive Design**: Professional UI that works on desktop and mobile

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Wouter (routing)
- **Backend**: Node.js, Express.js, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (OpenID Connect)
- **UI Components**: Radix UI with shadcn/ui

## Getting Started

### Prerequisites

- Node.js 18+ 
- PostgreSQL database
- Replit account (for authentication)

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd cargo-management-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory:
   ```env
   # Database Configuration
   DATABASE_URL=postgresql://username:password@localhost:5432/cargo_management
   PGHOST=localhost
   PGPORT=5432
   PGUSER=your_username
   PGPASSWORD=your_password
   PGDATABASE=cargo_management
   
   # Authentication (Replit Auth)
   REPL_ID=your_replit_app_id
   SESSION_SECRET=your_secure_session_secret
   REPLIT_DOMAINS=yourdomain.com
   ISSUER_URL=https://replit.com/oidc
   
   # Environment
   NODE_ENV=production
   ```

4. **Set up the database**
   ```bash
   # Create the database schema
   npm run db:push
   ```

5. **Start the application**
   ```bash
   # Development
   npm run dev
   
   # Production
   npm start
   ```

### Database Setup

The application uses PostgreSQL with Drizzle ORM. The schema includes:

- **users**: User authentication and profile data
- **companies**: Shipping company information
- **vehicles**: Vehicle fleet management
- **shipments**: Cargo shipment tracking
- **cargo_status_updates**: Shipment status history
- **sessions**: User session storage

### Authentication Setup

This application uses Replit Auth for authentication. To set up:

1. Create a Replit app
2. Enable OpenID Connect authentication
3. Configure the callback URL: `https://yourdomain.com/api/callback`
4. Set the appropriate environment variables

### API Endpoints

#### Authentication
- `GET /api/login` - Initiate login flow
- `GET /api/logout` - Logout user
- `GET /api/callback` - Authentication callback
- `GET /api/auth/user` - Get current user

#### Companies
- `GET /api/companies` - List all companies
- `POST /api/companies` - Create new company
- `PUT /api/companies/:id` - Update company
- `DELETE /api/companies/:id` - Delete company

#### Vehicles
- `GET /api/vehicles` - List all vehicles
- `POST /api/vehicles` - Create new vehicle
- `PUT /api/vehicles/:id` - Update vehicle
- `PUT /api/vehicles/:id/location` - Update vehicle location
- `DELETE /api/vehicles/:id` - Delete vehicle

#### Shipments
- `GET /api/shipments` - List shipments (paginated)
- `POST /api/shipments` - Create new shipment
- `PUT /api/shipments/:id` - Update shipment
- `PUT /api/shipments/:id/status` - Update shipment status
- `DELETE /api/shipments/:id` - Delete shipment

#### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics

### Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions
│   │   ├── pages/          # Application pages
│   │   └── App.tsx         # Main application component
├── server/                 # Backend Express application
│   ├── db.ts              # Database connection
│   ├── routes.ts          # API routes
│   ├── storage.ts         # Data access layer
│   ├── replitAuth.ts      # Authentication middleware
│   └── index.ts           # Server entry point
├── shared/                 # Shared types and schemas
│   └── schema.ts          # Database schema and types
└── package.json           # Dependencies and scripts
```

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run db:push` - Push database schema changes
- `npm run db:studio` - Open Drizzle Studio

### Language Support

The application supports Chinese (zh) and Mongolian (mn) languages. Language can be switched using the language selector in the header.

### User Roles

- **AD_OPERATOR**: Full administrative access to all features
- **AD_EREEN**: Limited access to cargo and vehicle management
- **AD_DRIVER**: Driver-specific access to assigned shipments and vehicles

### Deployment

1. Set up your PostgreSQL database
2. Configure environment variables
3. Build the application: `npm run build`
4. Start the production server: `npm start`

The application will be available at `http://localhost:5000`

### Security

- All routes are protected with authentication middleware
- Session data is stored securely in PostgreSQL
- CSRF protection is enabled
- Environment variables are used for sensitive configuration

### Support

For issues and questions, please refer to the codebase or create an issue in the repository.