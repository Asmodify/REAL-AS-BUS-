# Deployment Guide

## Download and Setup Instructions

### 1. Download Project Files

You can download all the project files by creating a zip archive of the current directory. The essential files include:

**Core Application Files:**
- `package.json` - Dependencies and scripts
- `tsconfig.json` - TypeScript configuration
- `vite.config.ts` - Build configuration
- `tailwind.config.ts` - Styling configuration
- `drizzle.config.ts` - Database configuration

**Backend Files:**
- `server/` - All backend code
- `shared/schema.ts` - Database schema and types

**Frontend Files:**
- `client/` - All frontend React code
- `components.json` - UI component configuration

### 2. Database Setup

#### Option A: PostgreSQL (Recommended)

1. **Install PostgreSQL** on your server
2. **Create a new database:**
   ```sql
   CREATE DATABASE cargo_management;
   CREATE USER cargo_user WITH PASSWORD 'secure_password';
   GRANT ALL PRIVILEGES ON DATABASE cargo_management TO cargo_user;
   ```

3. **Update your `.env` file:**
   ```env
   DATABASE_URL=postgresql://cargo_user:secure_password@localhost:5432/cargo_management
   PGHOST=localhost
   PGPORT=5432
   PGUSER=cargo_user
   PGPASSWORD=secure_password
   PGDATABASE=cargo_management
   ```

#### Option B: Cloud Database Services

**Neon (Recommended for production):**
1. Create account at neon.tech
2. Create new project
3. Copy connection string to `DATABASE_URL`

**Supabase:**
1. Create project at supabase.com
2. Go to Settings > Database
3. Copy connection string to `DATABASE_URL`

**Railway:**
1. Create project at railway.app
2. Add PostgreSQL service
3. Copy connection variables

### 3. Authentication Setup

#### Using Replit Auth (Current Setup)

1. **Create Replit App** (if deploying elsewhere)
2. **Configure OAuth:**
   - Callback URL: `https://yourdomain.com/api/callback`
   - Logout URL: `https://yourdomain.com`

#### Alternative: Replace with Other Auth Providers

If you want to use different authentication, you'll need to:

1. **Remove Replit Auth dependencies:**
   ```bash
   npm uninstall openid-client passport passport-local
   ```

2. **Install alternative auth:**
   ```bash
   # For Firebase Auth
   npm install firebase

   # For Auth0
   npm install auth0

   # For NextAuth.js
   npm install next-auth
   ```

3. **Update authentication files:**
   - Replace `server/replitAuth.ts`
   - Update `client/src/hooks/useAuth.ts`
   - Modify authentication routes in `server/routes.ts`

### 4. Environment Configuration

Create `.env` file with these required variables:

```env
# Database (Required)
DATABASE_URL=your_database_connection_string

# Authentication (Required)
SESSION_SECRET=your_32_character_minimum_secret_key
REPL_ID=your_app_id
REPLIT_DOMAINS=yourdomain.com
ISSUER_URL=https://replit.com/oidc

# Optional
NODE_ENV=production
PORT=5000
```

### 5. Installation and Build

```bash
# Install dependencies
npm install

# Push database schema
npm run db:push

# Build for production
npm run build

# Start production server
npm start
```

### 6. Deployment Options

#### Option A: Traditional Server (VPS/Dedicated)

1. **Upload files** to your server
2. **Install Node.js 18+**
3. **Install PM2** for process management:
   ```bash
   npm install -g pm2
   pm2 start npm --name "cargo-app" -- start
   pm2 save
   pm2 startup
   ```

#### Option B: Cloud Platforms

**Heroku:**
```bash
# Add buildpack
heroku buildpacks:set heroku/nodejs

# Add database addon
heroku addons:create heroku-postgresql:hobby-dev

# Deploy
git push heroku main
```

**Railway:**
1. Connect GitHub repository
2. Add environment variables
3. Deploy automatically

**DigitalOcean App Platform:**
1. Create new app from GitHub
2. Configure build and run commands
3. Add database component

#### Option C: Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 5000
CMD ["npm", "start"]
```

Create `docker-compose.yml`:
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/cargo
      - SESSION_SECRET=your_secret_here
    depends_on:
      - db
      
  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=cargo
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

### 7. Security Considerations

1. **Environment Variables:** Never commit `.env` files
2. **Session Secret:** Use a strong, random 32+ character string
3. **Database Security:** Use strong passwords and limit access
4. **HTTPS:** Always use SSL certificates in production
5. **Firewall:** Only expose necessary ports (80, 443, database port)

### 8. Monitoring and Maintenance

1. **Logs:** Check application logs regularly
2. **Database Backups:** Set up automated backups
3. **Updates:** Keep dependencies updated
4. **Performance:** Monitor CPU and memory usage

### 9. Troubleshooting

**Common Issues:**

1. **Database Connection Errors:**
   - Verify connection string format
   - Check firewall settings
   - Ensure database is running

2. **Authentication Issues:**
   - Verify callback URLs
   - Check environment variables
   - Ensure session secret is set

3. **Build Errors:**
   - Clear node_modules and reinstall
   - Check Node.js version compatibility
   - Verify all environment variables

**Support:**
- Check server logs: `pm2 logs` or `docker logs`
- Verify database connectivity: `npm run db:studio`
- Test API endpoints manually with curl or Postman