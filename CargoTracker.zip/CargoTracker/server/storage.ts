import {
  users,
  companies,
  vehicles,
  shipments,
  cargoStatusUpdates,
  type User,
  type UpsertUser,
  type Company,
  type InsertCompany,
  type Vehicle,
  type InsertVehicle,
  type Shipment,
  type InsertShipment,
  type CargoStatusUpdate,
  type InsertCargoStatusUpdate,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, ilike } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Company operations
  getCompanies(): Promise<Company[]>;
  getCompany(id: number): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompany(id: number, company: Partial<InsertCompany>): Promise<Company>;
  deleteCompany(id: number): Promise<void>;
  
  // Vehicle operations
  getVehicles(): Promise<Vehicle[]>;
  getVehicle(id: number): Promise<Vehicle | undefined>;
  getVehiclesByDriver(driverId: string): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: number, vehicle: Partial<InsertVehicle>): Promise<Vehicle>;
  updateVehicleLocation(id: number, latitude: number, longitude: number, location?: string): Promise<Vehicle>;
  deleteVehicle(id: number): Promise<void>;
  
  // Shipment operations
  getShipments(limit?: number, offset?: number): Promise<{ shipments: Shipment[]; total: number }>;
  getShipment(id: number): Promise<Shipment | undefined>;
  getShipmentsByDriver(driverId: string): Promise<Shipment[]>;
  getShipmentsByStatus(status: string): Promise<Shipment[]>;
  createShipment(shipment: InsertShipment): Promise<Shipment>;
  updateShipment(id: number, shipment: Partial<InsertShipment>): Promise<Shipment>;
  updateShipmentStatus(id: number, status: string): Promise<Shipment>;
  deleteShipment(id: number): Promise<void>;
  
  // Cargo status operations
  getCargoStatusUpdates(shipmentId: number): Promise<CargoStatusUpdate[]>;
  createCargoStatusUpdate(update: InsertCargoStatusUpdate): Promise<CargoStatusUpdate>;
  
  // Analytics
  getDashboardStats(): Promise<{
    activeShipments: number;
    totalVehicles: number;
    companies: number;
    onlineVehicles: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Company operations
  async getCompanies(): Promise<Company[]> {
    return await db.select().from(companies).where(eq(companies.isActive, true)).orderBy(companies.name);
  }

  async getCompany(id: number): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company;
  }

  async createCompany(company: InsertCompany): Promise<Company> {
    const [newCompany] = await db.insert(companies).values(company).returning();
    return newCompany;
  }

  async updateCompany(id: number, company: Partial<InsertCompany>): Promise<Company> {
    const [updatedCompany] = await db
      .update(companies)
      .set({ ...company, updatedAt: new Date() })
      .where(eq(companies.id, id))
      .returning();
    return updatedCompany;
  }

  async deleteCompany(id: number): Promise<void> {
    await db.update(companies).set({ isActive: false }).where(eq(companies.id, id));
  }

  // Vehicle operations
  async getVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles).orderBy(vehicles.licensePlate);
  }

  async getVehicle(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle;
  }

  async getVehiclesByDriver(driverId: string): Promise<Vehicle[]> {
    return await db.select().from(vehicles).where(eq(vehicles.driverId, driverId));
  }

  async createVehicle(vehicle: InsertVehicle): Promise<Vehicle> {
    const [newVehicle] = await db.insert(vehicles).values(vehicle).returning();
    return newVehicle;
  }

  async updateVehicle(id: number, vehicle: Partial<InsertVehicle>): Promise<Vehicle> {
    const [updatedVehicle] = await db
      .update(vehicles)
      .set({ ...vehicle, updatedAt: new Date() })
      .where(eq(vehicles.id, id))
      .returning();
    return updatedVehicle;
  }

  async updateVehicleLocation(id: number, latitude: number, longitude: number, location?: string): Promise<Vehicle> {
    const [updatedVehicle] = await db
      .update(vehicles)
      .set({
        latitude: latitude.toString(),
        longitude: longitude.toString(),
        currentLocation: location,
        lastUpdate: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(vehicles.id, id))
      .returning();
    return updatedVehicle;
  }

  async deleteVehicle(id: number): Promise<void> {
    await db.delete(vehicles).where(eq(vehicles.id, id));
  }

  // Shipment operations
  async getShipments(limit = 50, offset = 0): Promise<{ shipments: Shipment[]; total: number }> {
    const [shipmentsResult, totalResult] = await Promise.all([
      db.select().from(shipments).limit(limit).offset(offset).orderBy(desc(shipments.createdAt)),
      db.select({ count: shipments.id }).from(shipments),
    ]);
    
    return {
      shipments: shipmentsResult,
      total: totalResult.length,
    };
  }

  async getShipment(id: number): Promise<Shipment | undefined> {
    const [shipment] = await db.select().from(shipments).where(eq(shipments.id, id));
    return shipment;
  }

  async getShipmentsByDriver(driverId: string): Promise<Shipment[]> {
    return await db.select().from(shipments).where(eq(shipments.driverId, driverId)).orderBy(desc(shipments.createdAt));
  }

  async getShipmentsByStatus(status: string): Promise<Shipment[]> {
    return await db.select().from(shipments).where(eq(shipments.status, status as any)).orderBy(desc(shipments.createdAt));
  }

  async createShipment(shipment: InsertShipment): Promise<Shipment> {
    // Generate shipment ID
    const shipmentId = `SH-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
    
    const [newShipment] = await db
      .insert(shipments)
      .values({ ...shipment, shipmentId })
      .returning();
    return newShipment;
  }

  async updateShipment(id: number, shipment: Partial<InsertShipment>): Promise<Shipment> {
    const [updatedShipment] = await db
      .update(shipments)
      .set({ ...shipment, updatedAt: new Date() })
      .where(eq(shipments.id, id))
      .returning();
    return updatedShipment;
  }

  async updateShipmentStatus(id: number, status: string): Promise<Shipment> {
    const [updatedShipment] = await db
      .update(shipments)
      .set({ status: status as any, updatedAt: new Date() })
      .where(eq(shipments.id, id))
      .returning();
    return updatedShipment;
  }

  async deleteShipment(id: number): Promise<void> {
    await db.delete(shipments).where(eq(shipments.id, id));
  }

  // Cargo status operations
  async getCargoStatusUpdates(shipmentId: number): Promise<CargoStatusUpdate[]> {
    return await db
      .select()
      .from(cargoStatusUpdates)
      .where(eq(cargoStatusUpdates.shipmentId, shipmentId))
      .orderBy(desc(cargoStatusUpdates.createdAt));
  }

  async createCargoStatusUpdate(update: InsertCargoStatusUpdate): Promise<CargoStatusUpdate> {
    const [newUpdate] = await db.insert(cargoStatusUpdates).values(update).returning();
    return newUpdate;
  }

  // Analytics
  async getDashboardStats(): Promise<{
    activeShipments: number;
    totalVehicles: number;
    companies: number;
    onlineVehicles: number;
  }> {
    const [activeShipmentsResult, totalVehiclesResult, companiesResult, onlineVehiclesResult] = await Promise.all([
      db.select({ count: shipments.id }).from(shipments).where(or(eq(shipments.status, "pending"), eq(shipments.status, "in_transit"))),
      db.select({ count: vehicles.id }).from(vehicles),
      db.select({ count: companies.id }).from(companies).where(eq(companies.isActive, true)),
      db.select({ count: vehicles.id }).from(vehicles).where(or(eq(vehicles.status, "online"), eq(vehicles.status, "in_transit"))),
    ]);

    return {
      activeShipments: activeShipmentsResult.length,
      totalVehicles: totalVehiclesResult.length,
      companies: companiesResult.length,
      onlineVehicles: onlineVehiclesResult.length,
    };
  }
}

export const storage = new DatabaseStorage();
