#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚚 Cargo Management System Setup\n');

// Check if .env exists
if (!fs.existsSync('.env')) {
  console.log('📝 Creating .env file from template...');
  fs.copyFileSync('.env.example', '.env');
  console.log('✅ Created .env file. Please update with your database credentials.\n');
} else {
  console.log('✅ .env file already exists.\n');
}

// Check database connection
console.log('🔍 Checking database connection...');
try {
  execSync('npm run db:push', { stdio: 'inherit' });
  console.log('✅ Database schema updated successfully.\n');
} catch (error) {
  console.log('❌ Database connection failed. Please check your DATABASE_URL in .env\n');
}

// Install dependencies if needed
console.log('📦 Checking dependencies...');
if (!fs.existsSync('node_modules')) {
  console.log('Installing dependencies...');
  execSync('npm install', { stdio: 'inherit' });
  console.log('✅ Dependencies installed.\n');
} else {
  console.log('✅ Dependencies already installed.\n');
}

console.log('🎉 Setup complete! Run "npm run dev" to start the application.');