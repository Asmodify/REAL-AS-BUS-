import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  decimal,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { enum: ["AD_OPERATOR", "AD_EREEN", "AD_DRIVER"] }).notNull().default("AD_DRIVER"),
  language: varchar("language", { enum: ["zh", "mn"] }).notNull().default("zh"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Companies table
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameEn: text("name_en"),
  nameMn: text("name_mn"),
  address: text("address").notNull(),
  contactPerson: text("contact_person").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Vehicles table
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  licensePlate: text("license_plate").notNull().unique(),
  driverId: varchar("driver_id").references(() => users.id),
  model: text("model"),
  capacity: decimal("capacity", { precision: 10, scale: 2 }),
  status: varchar("status", { enum: ["online", "offline", "idle", "in_transit"] }).default("offline"),
  currentLocation: text("current_location"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  lastUpdate: timestamp("last_update").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Shipments table
export const shipments = pgTable("shipments", {
  id: serial("id").primaryKey(),
  shipmentId: text("shipment_id").notNull().unique(),
  originCompanyId: serial("origin_company_id").references(() => companies.id),
  destination: text("destination").notNull(),
  destinationAddress: text("destination_address"),
  driverId: varchar("driver_id").references(() => users.id),
  vehicleId: serial("vehicle_id").references(() => vehicles.id),
  status: varchar("status", { enum: ["pending", "in_transit", "delivered", "cancelled"] }).default("pending"),
  cargoDescription: text("cargo_description"),
  cargoWeight: decimal("cargo_weight", { precision: 10, scale: 2 }),
  cargoValue: decimal("cargo_value", { precision: 12, scale: 2 }),
  estimatedDelivery: timestamp("estimated_delivery"),
  actualDelivery: timestamp("actual_delivery"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cargo status updates table
export const cargoStatusUpdates = pgTable("cargo_status_updates", {
  id: serial("id").primaryKey(),
  shipmentId: serial("shipment_id").references(() => shipments.id),
  status: varchar("status").notNull(),
  location: text("location"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  notes: text("notes"),
  updatedBy: varchar("updated_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  vehicles: many(vehicles),
  shipments: many(shipments),
  statusUpdates: many(cargoStatusUpdates),
}));

export const companiesRelations = relations(companies, ({ many }) => ({
  shipments: many(shipments),
}));

export const vehiclesRelations = relations(vehicles, ({ one, many }) => ({
  driver: one(users, {
    fields: [vehicles.driverId],
    references: [users.id],
  }),
  shipments: many(shipments),
}));

export const shipmentsRelations = relations(shipments, ({ one, many }) => ({
  originCompany: one(companies, {
    fields: [shipments.originCompanyId],
    references: [companies.id],
  }),
  driver: one(users, {
    fields: [shipments.driverId],
    references: [users.id],
  }),
  vehicle: one(vehicles, {
    fields: [shipments.vehicleId],
    references: [vehicles.id],
  }),
  statusUpdates: many(cargoStatusUpdates),
}));

export const cargoStatusUpdatesRelations = relations(cargoStatusUpdates, ({ one }) => ({
  shipment: one(shipments, {
    fields: [cargoStatusUpdates.shipmentId],
    references: [shipments.id],
  }),
  updatedBy: one(users, {
    fields: [cargoStatusUpdates.updatedBy],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastUpdate: true,
});

export const insertShipmentSchema = createInsertSchema(shipments).omit({
  id: true,
  shipmentId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCargoStatusUpdateSchema = createInsertSchema(cargoStatusUpdates).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Company = typeof companies.$inferSelect;
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Shipment = typeof shipments.$inferSelect;
export type InsertShipment = z.infer<typeof insertShipmentSchema>;
export type CargoStatusUpdate = typeof cargoStatusUpdates.$inferSelect;
export type InsertCargoStatusUpdate = z.infer<typeof insertCargoStatusUpdateSchema>;
