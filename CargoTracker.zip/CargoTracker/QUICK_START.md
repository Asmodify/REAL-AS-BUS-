# Quick Start Guide

## Download and Setup Your Cargo Management System

### 1. Download All Files

To download the complete project, you'll need these essential files:

**Configuration Files:**
- `package.json` - Dependencies and build scripts
- `tsconfig.json` - TypeScript configuration  
- `vite.config.ts` - Build tool configuration
- `tailwind.config.ts` - Styling configuration
- `drizzle.config.ts` - Database ORM configuration
- `components.json` - UI components configuration
- `postcss.config.js` - CSS processing

**Backend Code:**
- `server/index.ts` - Main server entry point
- `server/routes.ts` - API route definitions
- `server/storage.ts` - Database operations
- `server/db.ts` - Database connection
- `server/replitAuth.ts` - Authentication system
- `server/vite.ts` - Development server setup

**Frontend Code:**
- `client/` - Complete React application folder
- All subdirectories and files in `client/src/`

**Shared Code:**
- `shared/schema.ts` - Database schema and TypeScript types

**Setup Files:**
- `.env.example` - Environment variables template
- `setup.js` - Automated setup script

### 2. Quick Setup Commands

```bash
# 1. Install dependencies
npm install

# 2. Copy environment template
cp .env.example .env

# 3. Edit .env with your database credentials
# DATABASE_URL=postgresql://username:password@localhost:5432/cargo_db
# SESSION_SECRET=your_32_character_random_string
# REPL_ID=your_replit_app_id (for auth)
# REPLIT_DOMAINS=yourdomain.com

# 4. Initialize database
npm run db:push

# 5. Start development server
npm run dev
```

### 3. Your Own Database Setup

Replace the DATABASE_URL with your PostgreSQL connection:

**Local PostgreSQL:**
```
DATABASE_URL=postgresql://username:password@localhost:5432/cargo_management
```

**Cloud Services:**
- **Neon:** `postgresql://user:pass@ep-xyz.us-east-2.aws.neon.tech/dbname`
- **Supabase:** `postgresql://postgres:pass@db.xyz.supabase.co:5432/postgres`
- **Railway:** `postgresql://postgres:pass@containers-us-west-xxx.railway.app:6543/railway`

### 4. Authentication Options

**Current Setup (Replit Auth):**
- Works out of the box on Replit
- For external deployment, you'll need a Replit app ID

**Alternative Options:**
Replace authentication by modifying these files:
- `server/replitAuth.ts` - Change auth provider
- `client/src/hooks/useAuth.ts` - Update frontend auth
- `server/routes.ts` - Modify auth routes

### 5. Production Deployment

**Build for production:**
```bash
npm run build
npm start
```

**Environment Variables for Production:**
```env
NODE_ENV=production
DATABASE_URL=your_production_database_url
SESSION_SECRET=secure_random_string
REPL_ID=your_app_id
REPLIT_DOMAINS=yourdomain.com
```

### 6. Features Available

- **Multi-role user system** (AD_OPERATOR, AD_EREEN, AD_DRIVER)
- **Company management** with full CRUD operations
- **Vehicle tracking** with real-time location updates
- **Cargo shipment management** with status tracking
- **Multilingual support** (Chinese and Mongolian)
- **Responsive dashboard** with analytics
- **Professional UI** with modern design

### 7. Technical Stack

- **Frontend:** React 18 + TypeScript + Tailwind CSS
- **Backend:** Node.js + Express + TypeScript
- **Database:** PostgreSQL with Drizzle ORM
- **Authentication:** Replit Auth (OpenID Connect)
- **UI Framework:** Radix UI with shadcn/ui components

The application will run on `http://localhost:5000` by default.

For detailed deployment instructions, see `DEPLOYMENT.md`.
For complete documentation, see `README.md`.